package com.example.mess;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.appcompat.app.AppCompatActivity;

public class splash_activity extends AppCompatActivity {
    private Handler handler = new Handler();
    private Runnable runnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);  // Ensure this points to your correct splash layout

        // Set the status bar color to black
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.setStatusBarColor(getResources().getColor(android.R.color.black));
        }

        // Set light status bar icons (for Android 6.0+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        // Define the action to run after the splash screen delay (3 seconds)
        runnable = new Runnable() {
            @Override
            public void run() {
                // Start MainActivity after a delay of 2 seconds
                Intent intent = new Intent(splash_activity.this, MainActivity.class);
                startActivity(intent);
                finish();  // Close the splash screen activity
            }
        };

        // Post the Runnable to be executed after a delay of 3000 milliseconds (3 seconds)
        handler.postDelayed(runnable, 2000);  // Splash screen will be visible for 3 seconds

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Remove any pending Runnable callback to avoid memory leaks
        handler.removeCallbacks(runnable);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Remove callbacks when the activity is paused to prevent any unintended execution
        handler.removeCallbacks(runnable);
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Ensure the handler is cleared when the activity is stopped
        handler.removeCallbacks(runnable);
    }
}
